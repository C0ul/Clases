/*
1.Agregar persona
2.Mostrar todos
3.Ordenar por DNI
4.Ordenar por apellido
*/
