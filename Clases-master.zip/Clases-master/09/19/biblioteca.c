#include "biblioteca.h"

void getArray(ePersona persona[], int cantidad)
{
    int index = indexIsEmpty(persona,cantidad);


        if(index==-1)
        {
            printf("no hay espacio para otra persona");
        }else
        {
           printf("\ningrese DNI: ");
           scanf("%f", &persona[index].dni);

           printf("ingrese nombre: ");
           fflush(stdin);
           gets(persona[index].nombre);

           printf("ingrese apellido: ");
           fflush(stdin);
           gets(persona[index].apellido);
        }
}
void showArray(ePersona persona[], int cantidad)
{
    int index = indexIsEmpty(persona,cantidad);

    if(index==-1)
        {
            printf("\nno hay espacio para mostrar");
            index=cantidad;
        }else
        {
            printf("\nsu DNI es %f\nsu nombre es %s %s\n", persona[index].dni, persona[index].nombre, persona[index].apellido);
        }
}
void inicializarArray(ePersona persona[], int cantidad)
{
    int i;
    for(i=0;i<cantidad;i++)
    {
        persona[i].estaVacio = 1;
    }
}
int indexIsEmpty(ePersona persona[], int cantidad)
{
    int index=-1;
    int i;

    for(i=0;i<cantidad;i++)
    {
        if(persona[i].estaVacio==1)
        {
            index=i;

            return index;
        }
    }
    return index;
}
int menu()
{

}
