#ifndef BIBLIOTECA_H_INCLUDED
#define BIBLIOTECA_H_INCLUDED

typedef struct
{
 float dni;
 char nombre[50];
 char apellido[50];
 int estaVacio;
}ePersona;

void getArray(ePersona persona[], int cantidad);
void showArray(ePersona persona[], int cantidad);
void inicializarArray(ePersona persona[], int cantidad);
int indexIsEmpty(ePersona persona[], int cantidad);
int menu();

#endif // BIBLIOTECA_H_INCLUDED
