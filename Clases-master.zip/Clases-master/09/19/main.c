#include <stdio.h>
#include <stdlib.h>
#include "biblioteca.h"
#include "biblioteca.c"
#define MAX 3

int main()
{
    ePersona persona[MAX];
    getArray(persona, MAX);
    showArray(persona, MAX);
    inicializarArray(persona,MAX);
    indexIsEmpty(persona,MAX);

    return 0;
}
