/** \brief sacar el factorial
 *
 * \param int
 * \return int
 *
 */
int factorial(int);













/*/** \brief pide un numero y lo valida en
           un rango especifico
 *
 * \param char[] texto que se va a mostrar
 * \param min int minimo valor dentro del rango
 * \param max int maximo valor dentro del rango
 * \return int numero ingresadoo
 *
 */
//int pedirEntero(char[], int min, int max);
