#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* pEntero = calloc(sizeof(int),5);
    int i;

    free(pEntero);

    for(i=0;i<5;i++)
    {
        printf("%d-", *(pEntero+i));
    }


    return 0;
}
