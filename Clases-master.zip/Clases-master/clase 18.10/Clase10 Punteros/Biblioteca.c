#include "Biblioteca.h"

sPersona* new_Persona()
{
    sPersona* miPersona;

    miPersona = malloc(sizeof(sPersona));

    return miPersona;
}

int mostrarPersona(sPersona* unaPersona)
{
    int retorno;
    if(unaPersona != NULL)
    {
        printf("La persona es: \n");
        printf("%d--%d--%.2f",unaPersona->legajo,
                              unaPersona->edad,
                              unaPersona->altura);
        retorno = 1;
    }
    else
    {
        retorno = -1;
    }

    return retorno;
}

int deletePersona(sPersona* unaPersona)
{
    int retorno;
    if(unaPersona != NULL)
    {
        free(unaPersona);
        retorno = 1;
    }
    else
    {
        retorno = -1;
    }

    return retorno;
}

sPersona* new_Persona_Parametros(int legajo,
                                  int edad,
                                   float altura)
{
    sPersona* miPersona = new_Persona();
    if(miPersona!=NULL)
    {
        miPersona->legajo=legajo;
        miPersona->edad=edad;
        miPersona->altura=altura;
    }

    return miPersona;
}
