#ifndef BIBLIOTECA_H_INCLUDED
#define BIBLIOTECA_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int legajo;
    int edad;
    float altura;

}sPersona;

sPersona* new_Persona();///Constructor por defecto
int deletePersona(sPersona*);
int mostrarPersona(sPersona*);
sPersona* new_Persona_Parametros(int, int, float);

#endif // BIBLIOTECA_H_INCLUDED
