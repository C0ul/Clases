#include <stdio.h>
#include <stdlib.h>
#include "Biblioteca.h"

int main()
{
    sPersona* pPersona;
    pPersona = new_Persona_Parametros(100,40,1.87);

    if(mostrarPersona(pPersona)!=1)
    {
        printf("Error al mostrar...\n");
    }

    deletePersona(pPersona);

    return 0;
}

